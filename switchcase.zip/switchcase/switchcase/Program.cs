﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace switchcase
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Set Console Color Green = 1");
            Console.WriteLine("Set Console Color Cyan = 2");
            Console.WriteLine("Set Console Color Magenta = 3");
            Console.Write("Enter number :");
            int n=Convert.ToInt32(Console.ReadLine());
            switch(n)
            {
                case 1: Console.BackgroundColor = ConsoleColor.Green;
                    Console.Clear();
                    break;

                case 2:Console.BackgroundColor = ConsoleColor.Cyan;
                    Console.Clear();
                    break;

                case 3:Console.BackgroundColor = ConsoleColor.Magenta;
                    Console.Clear();
                    break;

                default: Console.Write("Select 1 2 3");
                    break;
            }
            Console.Read();
        }
    }
}
